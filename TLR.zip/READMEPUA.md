 0xE080 Dev

 0xE081 Owner

 E000 zerospace

 E001 trilandgamemenu1

 E002 trilandgamemenu2

 E003 trilandgamemenu3

 E004 trilandgamemenu4

 E005 trilandgamemenu5

 E006 trilandgamemenu6

 E007 trilandgamemenu7

 E008 trilandgamemenu8



 e080 bar start

 e081 bar end

 e082 bar middle 1

 e083 2

 e084 3

 e085 4

 e086 5

 e087 6

 e088 7

 e089 8

 e08A 9

 e08B 10

 e08C 11

 e08D 12

 e08E 

 e08F 